# Benchmark Suite Summary

- Suite: `phase16-p1-gpu-v2`
- Family/tier: `backend_performance` / `performance`
- Total rows: 1
- Passed: 1; failed: 0; skipped: 0; incomplete: 0

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| chain_n3_cpu_cuda | chain_n3_cpu_cuda | passed | validation |
