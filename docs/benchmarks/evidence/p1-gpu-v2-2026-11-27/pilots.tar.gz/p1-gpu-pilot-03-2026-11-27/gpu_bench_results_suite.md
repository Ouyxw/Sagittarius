# Benchmark Suite Summary

- Suite: `phase16-p1-gpu-v2`
- Family/tier: `backend_performance` / `performance`
- Total rows: 3
- Passed: 0; failed: 0; skipped: 0; incomplete: 3

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| chain_n2_cpu_cuda | chain_n2_cpu_cuda | incomplete | validation |
| lattice_2x2_cpu_cuda | lattice_2x2_cpu_cuda | incomplete | validation |
| weighted_udg_n2_seed3_cpu_cuda | weighted_udg_n2_seed3_cpu_cuda | incomplete | validation |
