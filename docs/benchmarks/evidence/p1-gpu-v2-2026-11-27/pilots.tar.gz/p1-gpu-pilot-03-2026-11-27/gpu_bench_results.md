| scenario_id | status | N | basis_size | cpu_eligible | cuda_eligible | cpu_median_s | cpu_min_s | cpu_max_s | cpu_p25_s | cpu_p75_s | cuda_median_s | cuda_min_s | cuda_max_s | cuda_p25_s | cuda_p75_s | speedup | max_trajectory_error | t_cpu_s | t_gpu_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| chain_n2_cpu_cuda | incomplete | 2 | 3 | 1 | 1 | 0.254352 | 0.254352 | 0.254352 | 0.254352 | 0.254352 | 0.466858 | 0.466858 | 0.466858 | 0.466858 | 0.466858 | None | 6.10623e-16 | 0.254352 | 0.466858 |
| lattice_2x2_cpu_cuda | incomplete | 4 | 7 | 1 | 1 | 0.221704 | 0.221704 | 0.221704 | 0.221704 | 0.221704 | 0.483838 | 0.483838 | 0.483838 | 0.483838 | 0.483838 | None | 3.33067e-16 | 0.221704 | 0.483838 |
| weighted_udg_n2_seed3_cpu_cuda | incomplete | 2 | 3 | 1 | 1 | 2.17625 | 2.17625 | 2.17625 | 2.17625 | 2.17625 | 2.3858 | 2.3858 | 2.3858 | 2.3858 | 2.3858 | None | 2.96291e-15 | 2.17625 | 2.3858 |
