| scenario_id | status | N | basis_size | cpu_eligible | cuda_eligible | cpu_median_s | cpu_min_s | cpu_max_s | cpu_p25_s | cpu_p75_s | cuda_median_s | cuda_min_s | cuda_max_s | cuda_p25_s | cuda_p75_s | speedup | max_trajectory_error | t_cpu_s | t_gpu_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| chain_n2_cpu_cuda | incomplete | 2 | 3 | 1 | 1 | 0.215675 | 0.215675 | 0.215675 | 0.215675 | 0.215675 | 0.462303 | 0.462303 | 0.462303 | 0.462303 | 0.462303 | None | 6.10623e-16 | 0.215675 | 0.462303 |
