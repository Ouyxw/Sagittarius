# Benchmark Suite Summary

- Suite: `phase16-p1-open-system-v2`
- Family/tier: `open_system_dynamics` / `correctness`
- Total rows: 3
- Passed: 0; failed: 2; skipped: 0; incomplete: 1

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| performance-n20-reduced-chain-combined-scalar-mcwf-k100 | performance-n20-reduced-chain-combined-scalar-mcwf-k100 | incomplete | validation |
| performance-n1-full-driven-dephasing-scalar-mcwf-k500 | performance-n1-full-driven-dephasing-scalar-mcwf-k500 | failed | setup |
| performance-n2-reduced-chain-combined-scalar-mcwf-k500-raw | performance-n2-reduced-chain-combined-scalar-mcwf-k500-raw | failed | setup |
