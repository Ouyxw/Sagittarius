# Benchmark Suite Summary

- Suite: `phase16-p1-open-system-v2`
- Family/tier: `open_system_dynamics` / `correctness`
- Total rows: 3
- Passed: 1; failed: 1; skipped: 0; incomplete: 1

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| performance-n1-full-decay-decay-scalar-lindblad | performance-n1-full-decay-decay-scalar-lindblad | incomplete | validation |
| performance-n1-full-driven-dephasing-scalar-mcwf-k500 | performance-n1-full-driven-dephasing-scalar-mcwf-k500 | failed | reference |
| correctness-n1-full-coherence-dephasing-scalar-lindblad | correctness-n1-full-coherence-dephasing-scalar-lindblad | passed | artifact |
