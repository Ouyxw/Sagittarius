# Benchmark Suite Summary

- Suite: `phase16-p1-open-system-v2`
- Family/tier: `open_system_dynamics` / `correctness`
- Total rows: 3
- Passed: 0; failed: 3; skipped: 0; incomplete: 0

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| performance-n1-full-decay-decay-scalar-lindblad | performance-n1-full-decay-decay-scalar-lindblad | failed | setup |
| performance-n1-full-driven-dephasing-scalar-mcwf-k500 | performance-n1-full-driven-dephasing-scalar-mcwf-k500 | failed | setup |
| correctness-n1-full-coherence-dephasing-scalar-lindblad | correctness-n1-full-coherence-dephasing-scalar-lindblad | failed | setup |
