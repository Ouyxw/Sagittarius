# Benchmark Suite Summary

- Suite: `phase16-p1-open-system-v2`
- Family/tier: `open_system_dynamics` / `correctness`
- Total rows: 3
- Passed: 0; failed: 0; skipped: 0; incomplete: 3

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| performance-n12-reduced-chain-combined-scalar-lindblad | performance-n12-reduced-chain-combined-scalar-lindblad | incomplete | validation |
| performance-n20-reduced-chain-combined-scalar-mcwf-k1000 | performance-n20-reduced-chain-combined-scalar-mcwf-k1000 | incomplete | validation |
| performance-n1-full-driven-dephasing-scalar-lindblad | performance-n1-full-driven-dephasing-scalar-lindblad | incomplete | validation |
