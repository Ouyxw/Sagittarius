| row_id | status | N | basis_size | full_dim | pruned_fraction | time_s | median_time_s | max_rss | max_rss_unit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| chain-r1.1-n2 | passed | 2 | 3 | 4 | 0.25 | 0.269504 | 0.197922 | 1115980 | KiB on Linux, bytes on macOS |
