# Benchmark Suite Summary

- Suite: `phase16-p0-scaling-v2`
- Family/tier: `backend_performance` / `scaling`
- Total rows: 8
- Passed: 8; failed: 0; skipped: 0; incomplete: 0

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| chain-r1.1-n8 | chain-r1.1-n8 | passed | artifact |
| chain-r1.1-n20 | chain-r1.1-n20 | passed | artifact |
| chain-r2.1-n8 | chain-r2.1-n8 | passed | artifact |
| chain-r2.1-n20 | chain-r2.1-n20 | passed | artifact |
| rectangle-r1.1-n8 | rectangle-r1.1-n8 | passed | artifact |
| rectangle-r1.1-n20 | rectangle-r1.1-n20 | passed | artifact |
| rectangle-r2.1-n8 | rectangle-r2.1-n8 | passed | artifact |
| rectangle-r2.1-n20 | rectangle-r2.1-n20 | passed | artifact |
