| row_id | status | N | basis_size | full_dim | pruned_fraction | time_s | median_time_s | max_rss | max_rss_unit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| chain-r1.1-n8 | passed | 8 | 55 | 256 | 0.785156 | 0.224878 | 0.195044 | 1021016 | KiB on Linux, bytes on macOS |
| chain-r1.1-n20 | passed | 20 | 17711 | 1048576 | 0.983109 | 3.45855 | 3.4569 | 1236060 | KiB on Linux, bytes on macOS |
| chain-r2.1-n8 | passed | 8 | 28 | 256 | 0.890625 | 0.193999 | 0.193999 | 1006088 | KiB on Linux, bytes on macOS |
| chain-r2.1-n20 | passed | 20 | 2745 | 1048576 | 0.997382 | 0.659484 | 0.612461 | 1134388 | KiB on Linux, bytes on macOS |
| rectangle-r1.1-n8 | passed | 8 | 41 | 256 | 0.839844 | 0.196706 | 0.215235 | 1024076 | KiB on Linux, bytes on macOS |
| rectangle-r1.1-n20 | passed | 20 | 6743 | 1048576 | 0.993569 | 1.41776 | 1.41236 | 1174044 | KiB on Linux, bytes on macOS |
| rectangle-r2.1-n8 | passed | 8 | 17 | 256 | 0.933594 | 0.189319 | 0.189319 | 1010520 | KiB on Linux, bytes on macOS |
| rectangle-r2.1-n20 | passed | 20 | 437 | 1048576 | 0.999583 | 0.230895 | 0.233894 | 1043540 | KiB on Linux, bytes on macOS |
