# Benchmark Suite Summary

- Suite: `phase16-p1-solver-v2`
- Family/tier: `backend_performance` / `correctness`
- Total rows: 3
- Passed: 0; failed: 3; skipped: 0; incomplete: 0

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| rabi-tsit5-tol8-g101 | rabi-tsit5-tol8-g101 | failed | setup |
| addressed-rk4-s100-g101 | addressed-rk4-s100-g101 | failed | solve |
| ramp-tsit5-tol6-g101 | ramp-tsit5-tol6-g101 | failed | solve |
