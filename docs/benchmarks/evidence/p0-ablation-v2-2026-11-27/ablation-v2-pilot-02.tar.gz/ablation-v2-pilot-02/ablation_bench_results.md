| row_id | mode | status | workload | atom_count | full_dim | basis_size | repeats | total_time_s | time_per_operation_s | median_batch_time_s | reference_error | reference_relative_error | max_rss | max_rss_unit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| chain-n4-full_dense | full_dense | incomplete | matvec | 4 | 16 | 16 | 3 | 6.747e-06 | 2.249e-06 | 6.747e-06 | 0 | 0 | 936460 | KiB on Linux, bytes on macOS |
| chain-n4-full_sparse | full_sparse | incomplete | matvec | 4 | 16 | 16 | 3 | 2.6558e-05 | 8.85267e-06 | 2.6558e-05 | 2.54762e-16 | 7.64172e-17 | 937664 | KiB on Linux, bytes on macOS |
| chain-n4-reduced_matrix_free | reduced_matrix_free | incomplete | matvec | 4 | 16 | 8 | 3 | 4.4409e-05 | 1.4803e-05 | 4.4409e-05 | 4.44428e-16 | 1.34722e-16 | 939168 | KiB on Linux, bytes on macOS |
| chain-n4-reduced_sparse | reduced_sparse | incomplete | matvec | 4 | 16 | 8 | 3 | 2.6192e-05 | 8.73066e-06 | 2.6192e-05 | 4.44428e-16 | 1.34722e-16 | 937852 | KiB on Linux, bytes on macOS |
| chain-n4-reduced_sparse_gpu_cached | reduced_sparse_gpu_cached | skipped | ode_solve | 4 | 16 | 8 | None | None | None | None | None | None | None | None |
| chain-n8-full_dense | full_dense | incomplete | matvec | 8 | 256 | 256 | 3 | 6.3598e-05 | 2.11993e-05 | 6.3598e-05 | 0 | 0 | 944764 | KiB on Linux, bytes on macOS |
| chain-n8-full_sparse | full_sparse | incomplete | matvec | 8 | 256 | 256 | 3 | 4.2064e-05 | 1.40213e-05 | 4.2064e-05 | 2.48253e-16 | 1.37841e-16 | 944256 | KiB on Linux, bytes on macOS |
| chain-n8-reduced_matrix_free | reduced_matrix_free | incomplete | matvec | 8 | 256 | 55 | 3 | 0.000347079 | 0.000115693 | 0.000347079 | 4.57757e-16 | 1.96125e-16 | 922868 | KiB on Linux, bytes on macOS |
| chain-n8-reduced_sparse | reduced_sparse | incomplete | matvec | 8 | 256 | 55 | 3 | 2.5848e-05 | 8.616e-06 | 2.5848e-05 | 4.57757e-16 | 1.96125e-16 | 924996 | KiB on Linux, bytes on macOS |
| chain-n8-reduced_sparse_gpu_cached | reduced_sparse_gpu_cached | skipped | ode_solve | 8 | 256 | 55 | None | None | None | None | None | None | None | None |
