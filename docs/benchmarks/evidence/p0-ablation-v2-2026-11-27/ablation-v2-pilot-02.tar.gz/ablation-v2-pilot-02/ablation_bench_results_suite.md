# Benchmark Suite Summary

- Suite: `phase16-p0-ablation-v2`
- Family/tier: `backend_performance` / `performance`
- Total rows: 10
- Passed: 0; failed: 0; skipped: 2; incomplete: 8

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| chain-n4-full_dense | chain-n4-full_dense | incomplete | artifact |
| chain-n4-full_sparse | chain-n4-full_sparse | incomplete | artifact |
| chain-n4-reduced_matrix_free | chain-n4-reduced_matrix_free | incomplete | artifact |
| chain-n4-reduced_sparse | chain-n4-reduced_sparse | incomplete | artifact |
| chain-n4-reduced_sparse_gpu_cached | chain-n4-reduced_sparse_gpu_cached | skipped | setup |
| chain-n8-full_dense | chain-n8-full_dense | incomplete | artifact |
| chain-n8-full_sparse | chain-n8-full_sparse | incomplete | artifact |
| chain-n8-reduced_matrix_free | chain-n8-reduced_matrix_free | incomplete | artifact |
| chain-n8-reduced_sparse | chain-n8-reduced_sparse | incomplete | artifact |
| chain-n8-reduced_sparse_gpu_cached | chain-n8-reduced_sparse_gpu_cached | skipped | setup |
