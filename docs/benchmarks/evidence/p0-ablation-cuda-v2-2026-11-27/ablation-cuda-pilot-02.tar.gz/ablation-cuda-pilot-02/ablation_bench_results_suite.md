# Benchmark Suite Summary

- Suite: `phase16-p0-ablation-v2`
- Family/tier: `backend_performance` / `performance`
- Total rows: 1
- Passed: 0; failed: 0; skipped: 0; incomplete: 1

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| chain-n4-reduced_sparse_gpu_cached | chain-n4-reduced_sparse_gpu_cached | incomplete | artifact |
