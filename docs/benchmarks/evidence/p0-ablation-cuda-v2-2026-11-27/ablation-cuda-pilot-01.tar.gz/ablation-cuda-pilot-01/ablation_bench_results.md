| row_id | mode | status | workload | atom_count | full_dim | basis_size | repeats | total_time_s | time_per_operation_s | median_batch_time_s | reference_error | reference_relative_error | max_rss | max_rss_unit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| chain-n4-reduced_sparse_gpu_cached | reduced_sparse_gpu_cached | failed | ode_solve | 4 | 16 | 8 | 1 | None | None | None | None | None | 1996112 | KiB on Linux, bytes on macOS |
