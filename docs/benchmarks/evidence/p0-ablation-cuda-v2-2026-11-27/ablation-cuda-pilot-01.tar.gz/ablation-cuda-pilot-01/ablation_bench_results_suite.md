# Benchmark Suite Summary

- Suite: `phase16-p0-ablation-v2`
- Family/tier: `backend_performance` / `performance`
- Total rows: 1
- Passed: 0; failed: 1; skipped: 0; incomplete: 0

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| chain-n4-reduced_sparse_gpu_cached | chain-n4-reduced_sparse_gpu_cached | failed | solve |
