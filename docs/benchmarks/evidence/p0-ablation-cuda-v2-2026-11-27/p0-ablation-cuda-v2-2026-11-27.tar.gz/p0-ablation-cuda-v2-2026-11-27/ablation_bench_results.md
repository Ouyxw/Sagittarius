| row_id | mode | status | workload | atom_count | full_dim | basis_size | repeats | total_time_s | time_per_operation_s | median_batch_time_s | reference_error | reference_relative_error | max_rss | max_rss_unit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| chain-n4-reduced_sparse_gpu_cached | reduced_sparse_gpu_cached | passed | ode_solve | 4 | 16 | 8 | 1 | 0.434471 | 0.434471 | 0.412343 | None | None | 2065468 | KiB on Linux, bytes on macOS |
| chain-n8-reduced_sparse_gpu_cached | reduced_sparse_gpu_cached | passed | ode_solve | 8 | 256 | 55 | 1 | 0.663689 | 0.663689 | 0.677309 | None | None | 2106624 | KiB on Linux, bytes on macOS |
| chain-n12-reduced_sparse_gpu_cached | reduced_sparse_gpu_cached | passed | ode_solve | 12 | 4096 | 377 | 1 | 2.35073 | 2.35073 | 2.44287 | None | None | 2092608 | KiB on Linux, bytes on macOS |
| chain-n16-reduced_sparse_gpu_cached | reduced_sparse_gpu_cached | passed | ode_solve | 16 | 65536 | 2584 | 1 | 20.1637 | 20.1637 | 17.2456 | None | None | 2120124 | KiB on Linux, bytes on macOS |
| chain-n20-reduced_sparse_gpu_cached | reduced_sparse_gpu_cached | incomplete | ode_solve | 20 | 1048576 | 17711 | 1 | None | None | None | None | None | 2022268 | KiB on Linux, bytes on macOS |
