# Benchmark Suite Summary

- Suite: `phase16-p0-ablation-v2`
- Family/tier: `backend_performance` / `performance`
- Total rows: 5
- Passed: 4; failed: 0; skipped: 0; incomplete: 1

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| chain-n4-reduced_sparse_gpu_cached | chain-n4-reduced_sparse_gpu_cached | passed | artifact |
| chain-n8-reduced_sparse_gpu_cached | chain-n8-reduced_sparse_gpu_cached | passed | artifact |
| chain-n12-reduced_sparse_gpu_cached | chain-n12-reduced_sparse_gpu_cached | passed | artifact |
| chain-n16-reduced_sparse_gpu_cached | chain-n16-reduced_sparse_gpu_cached | passed | artifact |
| chain-n20-reduced_sparse_gpu_cached | chain-n20-reduced_sparse_gpu_cached | incomplete | solve |
