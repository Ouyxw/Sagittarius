# Benchmark Suite Summary

- Suite: `phase16-p1-observables-v2`
- Family/tier: `backend_performance` / `correctness`
- Total rows: 4
- Passed: 3; failed: 0; skipped: 0; incomplete: 1

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| correctness-n3-full-ground-mixed-c10-g21-original | correctness-n3-full-ground-mixed-c10-g21-original | passed | artifact |
| correctness-n3-reduced-distribution-mixed-c10-g21-original | correctness-n3-reduced-distribution-mixed-c10-g21-original | passed | artifact |
| correctness-n3-reduced-mcwf-mixed-c10-g21-original | correctness-n3-reduced-mcwf-mixed-c10-g21-original | passed | artifact |
| performance-n20-reduced-evolving-mixed-c64-g101-original | performance-n20-reduced-evolving-mixed-c64-g101-original | incomplete | validation |
