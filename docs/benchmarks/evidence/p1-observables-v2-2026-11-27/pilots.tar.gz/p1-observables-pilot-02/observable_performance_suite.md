# Benchmark Suite Summary

- Suite: `phase16-p1-observables-v2`
- Family/tier: `backend_performance` / `correctness`
- Total rows: 2
- Passed: 1; failed: 0; skipped: 0; incomplete: 1

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| correctness-n3-reduced-ground-mixed-c10-g21-original | correctness-n3-reduced-ground-mixed-c10-g21-original | passed | artifact |
| performance-n20-reduced-evolving-mixed-c16-g501-reverse | performance-n20-reduced-evolving-mixed-c16-g501-reverse | incomplete | validation |
