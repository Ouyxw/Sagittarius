# Benchmark Suite Summary

- Suite: `phase16-p1-mwis-v2`
- Family/tier: `optimization_aqc` / `performance`
- Total rows: 2
- Passed: 0; failed: 0; skipped: 0; incomplete: 2

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| udg_weighted_n8_seed103 | udg_weighted_n8_seed103 | incomplete | validation |
| udg_weighted_n20_seed103 | udg_weighted_n20_seed103 | incomplete | validation |
