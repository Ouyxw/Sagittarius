# Benchmark Suite Summary

- Suite: `phase16-p1-mwis-v2`
- Family/tier: `optimization_aqc` / `performance`
- Total rows: 1
- Passed: 0; failed: 0; skipped: 0; incomplete: 1

| Row ID | Scenario | Status | Stage |
| --- | --- | --- | --- |
| udg_weighted_n2_seed101 | udg_weighted_n2_seed101 | incomplete | validation |
