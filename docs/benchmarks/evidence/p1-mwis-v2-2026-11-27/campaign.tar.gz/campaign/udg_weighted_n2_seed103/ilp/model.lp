\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.09100486405 x_0 + 1.05178121679 x_1
Subject To
Binaries
x_0
x_1
End
