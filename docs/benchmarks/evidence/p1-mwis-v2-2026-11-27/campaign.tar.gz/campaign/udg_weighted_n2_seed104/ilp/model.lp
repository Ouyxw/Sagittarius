\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.10804441411 x_0 + 1.37694425906 x_1
Subject To
Binaries
x_0
x_1
End
