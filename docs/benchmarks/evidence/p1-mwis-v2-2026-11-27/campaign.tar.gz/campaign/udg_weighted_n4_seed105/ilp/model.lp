\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.04836472772 x_0 + 1.10300811802 x_1 + 1.30610223028 x_2
 + 1.36683788615 x_3
Subject To
_C1: x_1 + x_2 <= 1
_C2: x_1 + x_3 <= 1
Binaries
x_0
x_1
x_2
x_3
End
