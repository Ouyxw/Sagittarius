\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.41191838859 x_0 + 1.23194208015 x_1
Subject To
_C1: x_0 + x_1 <= 1
Binaries
x_0
x_1
End
