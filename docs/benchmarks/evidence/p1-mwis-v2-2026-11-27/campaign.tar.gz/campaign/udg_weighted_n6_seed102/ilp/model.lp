\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.41191838859 x_0 + 1.23194208015 x_1 + 1.4965959958 x_2
 + 1.17277496057 x_3 + 1.4621277253 x_4 + 1.08115478607 x_5
Subject To
_C1: x_0 + x_1 <= 1
_C2: x_2 + x_4 <= 1
Binaries
x_0
x_1
x_2
x_3
x_4
x_5
End
