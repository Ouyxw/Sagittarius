\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.10804441411 x_0 + 1.37694425906 x_1 + 1.32246568473 x_2
 + 1.26914861849 x_3 + 1.10955643546 x_4 + 1.13267455277 x_5
Subject To
_C1: x_0 + x_2 <= 1
_C2: x_0 + x_4 <= 1
_C3: x_1 + x_5 <= 1
_C4: x_2 + x_3 <= 1
_C5: x_2 + x_5 <= 1
Binaries
x_0
x_1
x_2
x_3
x_4
x_5
End
