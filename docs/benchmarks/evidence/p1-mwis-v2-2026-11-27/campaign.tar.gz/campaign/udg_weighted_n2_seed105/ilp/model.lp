\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.04836472772 x_0 + 1.10300811802 x_1
Subject To
_C1: x_0 + x_1 <= 1
Binaries
x_0
x_1
End
