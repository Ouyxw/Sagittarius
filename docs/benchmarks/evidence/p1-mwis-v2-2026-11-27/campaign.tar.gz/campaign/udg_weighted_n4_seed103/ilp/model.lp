\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.09100486405 x_0 + 1.05178121679 x_1 + 1.35064788181 x_2
 + 1.36999157217 x_3
Subject To
_C1: x_0 + x_2 <= 1
_C2: x_0 + x_3 <= 1
_C3: x_2 + x_3 <= 1
Binaries
x_0
x_1
x_2
x_3
End
