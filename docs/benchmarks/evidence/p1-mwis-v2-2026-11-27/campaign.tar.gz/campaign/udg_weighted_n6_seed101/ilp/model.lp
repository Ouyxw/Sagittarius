\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.39240270598 x_0 + 1.46136284321 x_1 + 1.48658840732 x_2
 + 1.34044811564 x_3 + 1.44739910154 x_4 + 1.17733951861 x_5
Subject To
_C1: x_0 + x_1 <= 1
_C2: x_0 + x_2 <= 1
_C3: x_1 + x_2 <= 1
_C4: x_1 + x_4 <= 1
_C5: x_1 + x_5 <= 1
_C6: x_2 + x_5 <= 1
Binaries
x_0
x_1
x_2
x_3
x_4
x_5
End
