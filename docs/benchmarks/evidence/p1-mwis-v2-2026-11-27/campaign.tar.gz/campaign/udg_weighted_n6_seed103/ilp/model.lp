\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.09100486405 x_0 + 1.05178121679 x_1 + 1.35064788181 x_2
 + 1.36999157217 x_3 + 1.15472952135 x_4 + 1.02793551136 x_5
Subject To
_C1: x_0 + x_3 <= 1
_C2: x_0 + x_5 <= 1
_C3: x_2 + x_3 <= 1
_C4: x_2 + x_4 <= 1
Binaries
x_0
x_1
x_2
x_3
x_4
x_5
End
