\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.39240270598 x_0 + 1.46136284321 x_1 + 1.48658840732 x_2
 + 1.34044811564 x_3
Subject To
_C1: x_0 + x_1 <= 1
_C2: x_0 + x_2 <= 1
_C3: x_1 + x_2 <= 1
Binaries
x_0
x_1
x_2
x_3
End
