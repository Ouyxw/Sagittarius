\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.04836472772 x_0 + 1.10300811802 x_1 + 1.30610223028 x_2
 + 1.36683788615 x_3 + 1.16273024885 x_4 + 1.24721252138 x_5
Subject To
_C1: x_1 + x_3 <= 1
_C2: x_1 + x_4 <= 1
_C3: x_1 + x_5 <= 1
_C4: x_3 + x_4 <= 1
_C5: x_3 + x_5 <= 1
Binaries
x_0
x_1
x_2
x_3
x_4
x_5
End
