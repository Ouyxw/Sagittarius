\* Sagittarius_MWIS_Performance *\
Maximize
OBJ: 1.39240270598 x_0 + 1.46136284321 x_1
Subject To
_C1: x_0 + x_1 <= 1
Binaries
x_0
x_1
End
